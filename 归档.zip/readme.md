- index
- project/
- subject/

```
|-- common/
|   |-- components/
|   |-- css/
|   |-- images/
|   |-- js/
|-- pages/
|   |-- city/
|   |   |-- shanghai.html  // 上海
|   |-- company/  // 公司
|   |-- history/
|   |-- people/
|   |   |-- wangbo.html  // 王勃
|   |-- ranking/
|   |-- tools/
|-- index.html

```