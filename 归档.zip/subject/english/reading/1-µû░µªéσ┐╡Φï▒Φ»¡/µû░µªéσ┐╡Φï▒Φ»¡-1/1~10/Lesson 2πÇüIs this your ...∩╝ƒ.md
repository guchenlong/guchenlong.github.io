# Lesson 2、Is this your ...？

## 单词

- `pen` n. 钢笔
- `pencil` n. 铅笔
- `book` n. 书
- `watch` n. 手表
- `coat` n. 上衣，外衣
- `dress` n. 连衣裙
- `skirt` n. 裙子
- `shirt` n. 衬衣
- `car` n. 小汽车
- `house` n. 房子
