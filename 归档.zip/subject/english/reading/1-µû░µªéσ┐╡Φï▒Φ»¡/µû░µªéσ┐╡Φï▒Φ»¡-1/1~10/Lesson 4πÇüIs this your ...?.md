# Lesson 4、Is this your ...?

## 单词

- `suit` n. 一套衣服
- `school` n. 学校
- `teacher` n. 老师
- `son` n. 儿子
- `daughter` n. 女儿
