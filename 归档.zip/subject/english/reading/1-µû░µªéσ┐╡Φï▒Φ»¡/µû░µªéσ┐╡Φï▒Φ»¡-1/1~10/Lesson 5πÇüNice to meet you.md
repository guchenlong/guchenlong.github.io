# Lesson 5、Nice to meet you

## 文章

> MR. BLAKE: Good morning.
> STUDENTS: Good morning, Mr. Blake.
> MR. BLAKE: This is Miss Sophie Dupont. Sophie is a new student. She is French.
> MR. BLAKE: Sophie, this is Hans. He is German.
> HANS: Nice to meet you.
> MR. BLAKE: And this is Naoko. She's Japanese.
> NAOKO: Nice to meet you.
> MR. BLAKE: And this is Chang-woo. He's Korean.
> CHANG-WOO: Nice to meet you.
> MR. BLAKE: And this is Luming. He's Chinese.
> LUMING: Nice to meet you.
> MR. BLAKE: And this is Xiaohui. She's Chinese, too.
> XIAOHUI: Nice to meet you.

## 单词

- `Mr.` 先生
- `good` adj. 好的
- `morning` n. 早晨
- `Miss` 小姐
- `new` adj. 新的
- `student` n. 学生
- `French` adj. 法国的；法国人
- `German` adj. 德国的；德国人
- `nice` adj. 美好的
- `meet` v. 遇见
- `Japanese` adj. 日本的；日本人
- `Korean` adj. 韩国的；韩国人
- `Chinese` adj. 中国的；中国人
- `too` adv. 也
