# Lesson 3、Sorry, sir.

## 文章

> My coat and my umbrella please.
> Here is my ticket.
> Thank you, sir.
> Number five
> Here's your umbrella and your coat.
> This is not my umbrella.
> Sorry, sir.
> Is this your umbrella?
> No, it isn't.
> Is this it?
> Yes, it is.
> Thank you very much.

## 单词

- `umbrella` n. 雨伞
- `please` int. 请
- `here` adv. 这里
- `my` adjective. 我的
- `ticket` n. 票
- `number` n. 号码
- `five` num. 五
- `sorry` adj. 对不起的
- `sir` n. 先生
- `cloakroom` n. 衣帽存放处
