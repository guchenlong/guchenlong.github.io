# Lesson 7、Are you a teacher?

## 文章

> ROBERT: I am a new student. My name's Robert.
> SOPHIE: Nice to meet you. My name's Sophie.
> ROBERT: Are you French?
> SOPHIE: Yes, I am.
> SOPHIE: Are you French, too?
> ROBERT: No, I am not.
> SOPHIE: What nationality are you?
> ROBERT: I'm Italian.
> ROBERT: Are you a teacher?
> SOPHIE: No, I'm not.
> ROBERT: What's your job?
> SOPHIE: I'm a keyboard operator.
> SOPHIE: What's your job?
> ROBERT: I'm an engineer.

## 单词

- `I` pron. 我
- `am` v. be 动词现在时第一人称单数
- `are` v. be 动词现在时复数
- `name` n. 名字
- `what` adj. & pron. 什么
- `nationality` n. 国籍
- `job` n. 工作
- `keyboard` n. 电脑键盘
- `operator` n. 操作员
- `engineer` n. 工程师
