# Lesson 8、What's your job?

## 单词

- `policeman` n. 警察
- `policewoman` n. 女警察
- `taxi driver` 出租汽车司机
- `air hostess` 空中小姐
- `postman` n. 邮递员
- `nurse` n. 护士
- `mechanic` n. 机械师
- `hairdresser` n. 理发师
- `housewife` n. 家庭妇女
- `milkman` n. 送牛奶的人
