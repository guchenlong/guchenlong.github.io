# Lesson 1、Excuse me

## 文章

> Excuse me!
> Yes?
> Is this your handbag?
> Pardon?
> Is this your handbag?
> Yes, it is.
> Thank you very much.

## 单词

- `excuse` v. 原谅
- `me` pron. 我
- `yes` adv. 是的
- `is` v. be 动词现在时第三人称单数
- `this` pron. 这
- `your` adjective. 你的，你们的
- `handbag` n. 手提包
- `pardon` n. 原谅，宽恕
- `it` pron. 它
- `thank you` v. 感谢
- `very much` adverb. 非常地
