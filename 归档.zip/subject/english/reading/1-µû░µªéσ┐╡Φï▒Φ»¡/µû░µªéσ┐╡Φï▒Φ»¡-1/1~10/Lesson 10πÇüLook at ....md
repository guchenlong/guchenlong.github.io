# Lesson 10、Look at ...

## 单词

- `fat` adj. 胖的
- `woman` n. 女人
- `thin` adj. 瘦的
- `tall` adj. 高的
- `short` adj. 矮的
- `dirty` adj. 脏的
- `clean` adj. 干净的
- `hot` adj. 热的
- `cold` adj. 冷的
- `old` adj. 老的
- `yound` adj. 年轻的
- `busy` adj. 忙的
- `lazy` adj. 懒的
