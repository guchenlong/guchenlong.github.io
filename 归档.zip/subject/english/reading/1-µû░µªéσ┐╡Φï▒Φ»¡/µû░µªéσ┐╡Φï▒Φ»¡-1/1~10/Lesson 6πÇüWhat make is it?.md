# Lesson 6、What make is it?

## 单词

- `make` n. 牌号
- `Swedish` adj. 瑞典的
- `English` adj. 英国的
- `American` adj. 美国的
- `Italian` adj. 意大利的
- `Volvo` n. 沃尔沃
- `Peugeot` n. 标致
- `Mercedes` n. 梅赛德斯
- `Toyota` n. 丰田
- `Daewoo` n. 大宇
- `Mini` n. 迷你
- `Ford` n. 福特
- `Fiat` n. 菲亚特
