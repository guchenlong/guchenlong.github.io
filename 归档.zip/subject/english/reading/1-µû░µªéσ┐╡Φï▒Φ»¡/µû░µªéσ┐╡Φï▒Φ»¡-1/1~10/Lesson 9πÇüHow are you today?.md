# Lesson 9、How are you today?

## 文章

> STEVEN: Hello, Hellen.
> HELLEN: Hi, Steven.
> STEVEN: How are you today?
> HELLEN: I'm very well, thank you. And you?
> STEVEN: I'm fine, thanks.
> STEVEN: How is Tony?
> HELEN: He's fine, thanks. How's Emma?
> STEVEN: She's very well, too, Helen.
> STEVEN: Goodbye, Helen. Nice to see you.
> HELEN: Nice to see you, too, Steven. Goodbye.

## 单词

- `hello` int. 喂
- `hi` int. 喂，嗨
- `how` adv. 怎样
- `today` adv. 今天
- `well` adj. 身体好的
- `fine` adj. 美好的
- `thanks` int. 谢谢
- `goodbye` int. 再见
- `see` v. 看见
