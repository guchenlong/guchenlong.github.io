# Lesson 36、Where ...?

## 单词

- `beside` prep. 在...旁边
- `off` prep. 离开
