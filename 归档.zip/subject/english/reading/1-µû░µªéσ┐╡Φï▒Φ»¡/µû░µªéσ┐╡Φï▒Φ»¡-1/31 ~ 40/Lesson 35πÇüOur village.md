# Lesson 35、Our village

## 文章

> This is a photograph of our village.
> Our village is in a valley.
> It is between two hills.
> The village is on a river.
>
> Here is another photograph of the village.
> My wife and I are walking alone the banks of the river.
> We are on the left.
> There is a boy in the water.
> He is swimming across the river.
>
> Here is another photograph.
> This is the school building.
> It is beside a park.
> The aprk is on the right.
> Some children are comming out of the building.
> Some of them are going into the park.

## 单词

- `photograph` n. 照片
- `village` n. 村庄
- `valley` n. 山谷
- `between` prep. 在…之间
- `hill` n. 小山
- `another` det. 另一个
- `wife` n. 妻子
- `along` prep. 沿着
- `bank` n. 河岸
- `water` n. 水
- `swim` v. 游泳
- `building` n. 大楼
- `park` n. 公园
- `into` prep. 进入
