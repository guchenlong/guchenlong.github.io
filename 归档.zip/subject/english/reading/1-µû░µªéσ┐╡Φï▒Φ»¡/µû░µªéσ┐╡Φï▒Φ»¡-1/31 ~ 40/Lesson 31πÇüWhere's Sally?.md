# Lesson 31、Where's Sally?

## 文章

> JEAN: Where's Sally, Jack?
> JACK: She's in the garden, Jean.
> JEAN: What's she doing?
> JACK: She's sitting under the tree.
> JEAN: Is Tim in the garden, too?
> JACK: Yes, he is. He's climbing the tree.
> JEAN: I beg your pardon? Who's climbing the tree?
> JACK: Tim is.
> JEAN: What about the dog?
> JACK: The dog's in the garden, too. It's runnig across the grass. It's running after a cat.

## 单词

- `garden` n. 花园
- `under` prep. 在...之下
- `tree` n. 树
- `climb` v. 爬
- `who` pron. 谁
- `run` v. 跑
- `grass` n. 草地
- `after` prep. 在...之后
- `across` prep. 横过
- `cat` n. 猫
