# Lesson 32、What's he

## 单词

- `type` v. 打字
- `letter` n. 信
- `basket` n. 篮子
- `eat` v. 吃
- `bone` n. 骨头
- `clean` v. 清洗
- `tooth` n. 牙齿
- `cook` v. 做
- `milk` n. 牛奶
- `meal` n. 饭
- `drink` v. 喝
- `tap` n. (水)龙头
