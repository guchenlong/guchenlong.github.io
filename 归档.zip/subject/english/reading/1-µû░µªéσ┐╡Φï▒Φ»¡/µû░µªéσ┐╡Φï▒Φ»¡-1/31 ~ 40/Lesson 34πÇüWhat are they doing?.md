# Lesson 34、What are they doing?

## 单词

- `sleep` v. 睡觉
- `shave` v. 刮脸
- `cry` v. 哭，喊
- `wash` v. 洗
- `wait` v. 等
- `jump` v. 跳
