# Lesson 33、A fine day

## 文章

> It is a fine day today.
> There are some clouds in the sky,
> but the sun is shining.
> Mr. Jones is with his family.
> They are walking over the bridge.
> There are some boats on the river.
> Mr. Jones and his wife are looking at them.
> Sally is looking at a big ship.
> The ship is going under the bridge.
> Tim is looking at an aeroplane.
> The aeroplane is flying over the river.

## 单词

- `day` n. 日子
- `cloud` n. 云
- `sky` n. 天空
- `sun` n. 太阳
- `shine` v. 照耀
- `with` prep. 和...在一起
- `family` n. 家庭(成员)
- `walk` v. 走路
- `over` prep. 跨越
- `bridge` n. 桥
- `boat` n. 船
- `river` n. 河
- `ship` n. 轮船
- `aeroplane` n. 飞机
- `fly` v. 飞
