# Lesson 20、Look at them!

## 单词

- `big` adj. 大的
- `small` adj. 小的
- `open` adj. 开着的
- `shut` adj. 关着的
- `light` adj. 轻的
- `heavy` adj. 重的
- `long` adj. 长的
- `shoe` n. 鞋子
- `grandfather` n. 祖父
- `grandmother` n. 祖母
