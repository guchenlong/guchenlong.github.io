# Lesson 12、Whose is this?

## 单词

- `father` n. 父亲
- `mother` n. 母亲
- `blouse` n. 女衬衫
- `sister` n. 姐，妹
- `tie` n. 领带
- `brother` n. 兄，弟
- `his` adjective. 他的
- `her` adjective. 她的
