# Lesson 19、Tired and thirsty

## 文章

> MOTHER: What's the matter, children?
> GIRL: We're tired ...
> BOY: ... and thirsty, Mum.
> MOTHER: Sit down here.
> MOTHER: Are you all right now?
> BOY: No, we aren't.
> MOTHER: Look! There's an ice cream man.
> MOTHER: Two ice creams please.
> MOTHER: Here you are, children.
> CHILDREN: Thanks, Mum.
> GIRL: These ice creams are nice.
> MOTHER: Are you all right now?
> CHILDREN: Yes, we are, thank you!

## 单词

- `matter` n. 事情
- `children` n. 孩子们
- `tired` adj. 累的
- `boy` n. 男孩
- `thirsty` adj. 渴的
- `mum` n. 妈妈
- `sit down` 坐下
- `right` adj. 好，可以
- `ice cream` n. 冰淇淋
