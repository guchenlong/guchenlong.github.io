# Lesson 14、What colour is your ...?

## 单词

- `case` n. 箱子
- `carpet` n. 地毯
- `dog` n. 狗
