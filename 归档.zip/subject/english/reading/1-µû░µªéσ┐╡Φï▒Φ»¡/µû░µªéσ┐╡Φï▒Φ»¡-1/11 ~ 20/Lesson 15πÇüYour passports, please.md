# Lesson 15、Your passports, please.

## 文章

> CUSTOMS OFFICER: Are you Swedish?
> GIRLS: No, we are not. We are Danish.
> CUSTOMS OFFICER: Are your friends Danish, too?
> GIRLS: No, they aren't. They are Norwegian.
> CUSTOMS OFFICER: Your passports, please.
> GIRLS: Here they are.
> CUSTOMS OFFICER: Are these your cases?
> GIRLS: No, they aren't.
> GIRLS: Our cases are brown. Here they are.
> CUSTOMS OFFICER: Are you tourists?
> GIRLS: Yes, we are.
> CUSTOMS OFFICER: Are your friends tourists, too?
> GIRLS: Yes, they are.
> CUSTOMES OFFICER: That's fine.
> GIRLS: Thank you very much.

## 单词

- `customs` n. 海关
- `officer` n. 官员
- `girl` n. 女孩，姑娘
- `Danish` adj. 丹麦的
- `friend` n. 朋友
- `Norwegian` adj. 挪威的
- `passport` n. 护照
- `brown` adj. 棕色的
- `tourist` n. 旅游者
