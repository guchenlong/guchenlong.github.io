# Lesson 16、Are you ...?

## 单词

- `Russian` adj. 俄罗斯的
- `Dutch` adj. 荷兰的
- `these` pron. 这些
- `red` adj. 红色的
- `grey` adj. 灰色的
- `yellow` adj. 黄色的
- `black` adj. 黑色的
- `orange` adj. 橙色的
