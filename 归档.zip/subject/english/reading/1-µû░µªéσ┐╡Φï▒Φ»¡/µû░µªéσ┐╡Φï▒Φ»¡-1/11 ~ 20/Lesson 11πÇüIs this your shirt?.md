# Lesson 11、Is this your shirt?

## 文章

> TEACHER: Whose shirt is that?
> TEACHER: Is this your shirt, Dave?
> DAVE: No, sir. It's not my shirt.
> DAVE: This is my shirt. My shirt's blue.
> TEACHER: Is this shirt Tim's?
> DAVE: Perhaps it is, sir. Tim's shirt's white.
> TEACHER: Tim!
> TIM: Yes, sir?
> TEACHER: Is this your shirt?
> TIM: Yes, sir.
> TEACHER: Here you are. Catch!
> TIM: Thant you, sir!

## 单词

- `whose` pron. 谁的
- `blue` adj. 蓝色的
- `perhaps` adv. 大概
- `white` adj. 白色的
- `catch` v. 抓住
