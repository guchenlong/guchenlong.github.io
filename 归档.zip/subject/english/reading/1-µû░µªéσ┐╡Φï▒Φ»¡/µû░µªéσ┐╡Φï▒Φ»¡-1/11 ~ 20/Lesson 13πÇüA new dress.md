# Lesson 13、A new dress

## 文章

> LOUISE: What colour's your new dress?
> ANNA: It's green.
> ANNA: Come upstairs and see it.
> LOUISE: Thank you.
> ANNA: Look! Here it is.
> LOUISE: That's a nice dress. It's very smart.
> ANNA: My hat's new, too.
> LOUISE: What colour is it?
> ANNA: It's the same colour. It's green, too.
> LOUISE: That is a lovely hat!

## 单词

- `colour` n. 颜色
- `green` adj. 绿色的
- `come` v. 来
- `upstairs` adj. 楼上
- `smart` adj. 漂亮的
- `hat` n. 帽子
- `same` adj. 相同的
- `lovely` adj. 可爱的
