# Lesson 25、Mrs. Smith's kitchen

## 文章

> Mrs. Smith's kitchen is small.
> There is a refrigerator in the kitchen.
> The refrigerator is white.
> It is on the right.
> There is an electric cooker in the kitchen.
> The cooker is blue.
> it is on the left.
> There is a table in the middle of the room.
> There is a bottle on the table.
> The bottle is empty.
> There is a cup on the table, too.
> The cup is clean.

## 单词

- `Mrs.` 夫人
- `kitchen` n. 厨房
- `refrigerator` n. 电冰箱
- `right` n. 右边
- `electric` adj. 带电的
- `left` n. 左边
- `cooker` n. 炉子
- `middle` n. 中间
- `of` (属于)...的
- `room` n. 房间
- `cup` n. 杯子
