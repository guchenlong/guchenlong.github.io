# Lesson 22、Give me

## 单词

- `empty` adj. 空的
- `full` adj. 满的
- `large` adj. 大的
- `little` adj. 小的
- `sharp` adj. 尖的，锋利的
- `small` adj. 小的
- `big` adj. 大的
- `blunt` adj. 钝的
- `box` n. 盒子
- `glass` n. 杯子
- `cup` n. 茶杯
- `bottle` n. 瓶子
- `tin` n. 罐头
- `knife` n. 刀子
- `fork` n. 叉子
- `spoon` n. 勺子
