# Lesson 23、Which glasses?

## 文章

> MAN: Give me some glasses please. Jane.
> WOMAN: Which glasses?
> WOMAN: These glasses?
> MAN: No, not those. The ones on the shelf.
> WOMAN: These?
> MAN: Yes, please.
> WOMAN: Here you are.
> MAN: Thanks.

## 单词

- `on` prep. 在...上
- `shelf` n. 架子；搁板
