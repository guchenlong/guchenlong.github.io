# Lesson 26、Where is it?

## 单词

- `where` adv. 在哪里
- `in` prep. 在...里
