# Lesson 27、Mrs. Smith's living room

## 文章

> Mrs. Smith's living room is large.
> There is a television in the room.
> The television is near the window.
> There are some magazines on the television.
> There is a table in the room.
> There are some newspapers on the table.
> There are some armchairs in the room.
> The armchairs are near the table.
> There is a stereo in the room.
> The stereo is near the door.
> There are some books on the stereo.
> There are some pictures in the room.
> The pictures are on the wall.

## 单词

- `living room` 客厅
- `near` prep. 靠近
- `window` n. 窗户
- `armchair` n. 扶手椅
- `door` n. 门
- `picture` n. 图画
- `wall` n. 墙
