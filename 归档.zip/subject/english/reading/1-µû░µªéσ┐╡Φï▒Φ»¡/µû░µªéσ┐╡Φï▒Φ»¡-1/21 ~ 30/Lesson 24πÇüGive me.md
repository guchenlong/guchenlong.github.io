# Lesson 24、Give me

## 单词

- `desk` n. 课桌
- `table` n. 桌子
- `plate` n. 盘子
- `cupboard` n. 食橱
- `cigarette` n. 香烟
- `television` n. 电视机
- `floor` n. 地板
- `dressing table` 梳妆台
- `magazine` n. 杂志
- `bed` n. 床
- `newspaper` n. 报纸
- `stereo` n. 立体声音响
