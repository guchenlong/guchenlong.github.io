# Lesson 29、Come in, Amy.

## 文章

> MRS. JONES: Come in, Amy.
> MRS. JONES: Shut the door, please.
> MRS. JONES: This bedroom's very untidy.
> AMY: What must I do, Mrs. Jones?
> MRS. JONES: Open the window and air the room.
> MRS. JONES: Then put these clothes in the wardrobe.
> MRS. JONERS: Then make the bed.
> MRS. JONES: Dust the dressing table.
> MRS. JONES: Then sweep the floor.

## 单词

- `shut` v. 关闭
- `bedroom` n. 卧室
- `untidy` adj. 乱的
- `must` verb. 必须
- `open` v. 打开
- `air` v. 使...通风
- `put` v. 放置
- `clothes` n. 衣服
- `wardrobe` n. 衣柜
- `dust` v. 掸掉灰尘
- `sweep` v. 扫
