# Lesson 21、Which book?

## 文章

> MAN: Give me a book please, Jane.
> WOMAN: Which book?
> WOMAN: This one?
> MAN: No, not that one. The red one.
> WOMAN: This one?
> MAN: Yes, please.
> WOMAN: Here you are.
> MAN: Thank you.

## 单词

- `give` v. 给
- `one` pron. 一个
- `which` 哪一个
