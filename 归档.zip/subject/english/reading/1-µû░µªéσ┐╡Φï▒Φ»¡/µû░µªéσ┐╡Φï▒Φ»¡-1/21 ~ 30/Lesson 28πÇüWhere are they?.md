# Lesson 28、Where are they?

## 单词

- `trousers` n. 长裤
