# Lesson 30、What must I do?

## 单词

- `empty` v. 倒空
- `read` v. 读
- `sharpen` v. 消尖
- `put on` 穿上
- `take off` 脱掉
- `turn on` 开（电灯）
- `turn off` 关（电灯）
